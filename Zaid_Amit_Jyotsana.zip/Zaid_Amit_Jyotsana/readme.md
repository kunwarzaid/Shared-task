Git Repo
https://github.com/kunwarzaid/Shared_Task/tree/main

Details on how to run the code is present in the git repo